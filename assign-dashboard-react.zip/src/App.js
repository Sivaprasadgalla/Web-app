import './App.css';
import Assign from './Components/Assign';

function App() {
  return (
    <div className="App">
      <Assign />
    </div>
  );
}

export default App;
